================================================================
  CZ AUTOZ  -  by Callatic
  Server setup files :: Armoured Pack
================================================================

  ***  HOW TO INSTALL  -  PLEASE READ  ***

  Almost every file in this folder is MERGED into a file you
  ALREADY have on your server. OPEN your existing file and PASTE
  the new entries in. Do NOT drop these in to overwrite / replace
  your server files - that would wipe your own setup.

  The ONE exception is Trader_ExpansionMarket.json, which is a
  brand-new category file you ADD to your Market folder (it does
  not replace anything).

----------------------------------------------------------------
  ECONOMY FILES
----------------------------------------------------------------
  types.xml                    MERGE the <type> entries into your EXISTING
                               mpmissions\<your.map>\db\types.xml
  events.xml                   MERGE the <event> entries into your EXISTING
                               mpmissions\<your.map>\db\events.xml
  cfgeventspawns.xml           MERGE the <event> position blocks into your
                               EXISTING mpmissions\<your.map>\cfgeventspawns.xml

----------------------------------------------------------------
  TRADER FILES  (use the one for your trader mod)
----------------------------------------------------------------
  Trader_DrJones.txt           MERGE the <Category> blocks into your EXISTING
                               TraderConfig.txt  (Trader by Dr Jones)
  Trader_TraderPlus.json       (PRICES) MERGE the categories into the
                               "TraderCategories" array of your EXISTING
                               TraderPlusPriceConfig.json
  Trader_TraderPlus_VehiclesConfig.json  (ATTACHMENTS) MERGE the entries
                               into the "VehiclesParts" array of your EXISTING
                               TraderPlusVehiclesConfig.json, so a bought vehicle
                               arrives with its doors, wheels and battery instead
                               of bare
  Trader_ExpansionMarket.json  ADD this as a NEW category file in your profile's
                               ExpansionMod\Market\ folder (sits alongside your
                               other market files, replaces nothing) - OR merge its
                               "Items" into one of your existing category files.

  Prices are pre-set and identical across all three systems.
  Vehicles sell as vehicles; doors / wheels / parts sell as items.
  Expansion vehicles include SpawnAttachments so they sell built.

----------------------------------------------------------------
  QUICK SETUP
----------------------------------------------------------------
  1. WHITELIST your server IP in #ip-whitelisting on our Discord
     (each mod is whitelisted on its own; use submit-all for all you
     own). Until you do, vehicles spawn but the engines WON'T start.
  2. OPEN your mission's db\types.xml and MERGE in the entries from
     types.xml here (keep all of your existing entries).
  3. Add the vehicles to ONE trader by MERGING the matching trader
     file into your existing trader config (see above).
  4. (Optional) MERGE events.xml + cfgeventspawns.xml into your
     existing files for fixed map spawns.
  No cfgeconomycore.xml edit and NO Community Framework needed.

  Parts: generic spares spawn in Industrial loot; colour variants are
  nominal=0 (no loot spam). Vehicles never auto-spawn.

----------------------------------------------------------------
  HELP & DOCS
----------------------------------------------------------------
  Docs:     https://docs.czautoz.co.uk
  Discord:  https://discord.gg/kAm8KyH58d

  A vouch in #cz-vouches and a Workshop upvote really help. Thank you!
================================================================
