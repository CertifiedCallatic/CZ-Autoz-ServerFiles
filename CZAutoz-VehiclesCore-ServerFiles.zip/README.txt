================================================================
  CZ AUTOZ  -  by Callatic
  Server setup files :: Vehicles Core
================================================================

  Vehicles Core is REQUIRED by every paid CZ Autoz vehicle mod
  (tiers, packs and single cars). Load it on the server AND on
  every client, alongside your vehicle mods. Without it the paid
  vehicles will not load.

  ***  HOW TO INSTALL  -  PLEASE READ  ***

  Every file in this folder is MERGED into a file you ALREADY
  have on your server. OPEN your existing file and PASTE the new
  entries in. Do NOT overwrite your server files with these.

  The ONE exception is Trader_ExpansionMarket.json, which is a
  brand-new category file you ADD to your Market folder.

----------------------------------------------------------------
  QUICK SETUP
----------------------------------------------------------------
  1. Add @CZAutozVehiclesCore to -mod= on the server and on
     clients, together with your CZ Autoz vehicle mods.
  2. Whitelist your server's public IP + port with the
     #ip-whitelisting bot on our Discord or at
     czautoz.co.uk/whitelist (use submit-all for everything you own).
  3. MERGE types.xml (below) and one trader file.
  4. Start the server once. It creates profiles\CZAutoz\Cars\
     (see SERVER FILES). Open the Vehicle Admin Panel in game
     (Shift + F10) to change
     settings; no file editing needed.
  No cfgeconomycore.xml edit and NO Community Framework needed.

----------------------------------------------------------------
  ECONOMY AND TRADER FILES
----------------------------------------------------------------
  types.xml                    MERGE the <type> entries into your EXISTING
                               mpmissions\<your.map>\db\types.xml
  Trader_DrJones.txt           MERGE the <Category> block into your EXISTING
                               TraderConfig.txt  (Trader by Dr Jones)
  Trader_TraderPlus.json       MERGE the category into the "TraderCategories"
                               array of your EXISTING TraderPlusPriceConfig.json
  Trader_ExpansionMarket.json  ADD as a NEW category file in your profile's
                               ExpansionMod\Market\ folder

  Prices are pre-set and identical across all three systems.

----------------------------------------------------------------
  THE ADD-ON ITEMS  (all fit CZ Autoz vehicles)
----------------------------------------------------------------
  Satnav           Windscreen satnav with a live map, your position,
                   heading and a destination. Runs on the vehicle's
                   power and only works while fitted to a vehicle.
  Dashcam          Records drives, crashes and hits on the vehicle's
                   power. Hold it with a charged 9V battery in it to
                   review the footage. The battery also lets it guard
                   the parked vehicle.
  Car GPS Tracker  Fit it with a satnav to see where the vehicle is from
                   anywhere. Needs a 9V battery.
  Car Alarm        Sounds the horn and flashes the lights when the parked
                   vehicle is hit. Needs a 9V battery.
  Nitrous Kit      Hold the nitrous key in gear for a burst of speed.
  ECU Tune Kit     Pops and crackles when you lift off the throttle at
                   high revs. It does not change engine power.
  Sports Exhaust   Fitted with the ECU Tune Kit: louder pops, bangs on
                   gear changes and flames from the exhaust. On its own
                   it does nothing.
  Roof Box         Extra storage on the roof.
  Lightbar         Red, blue and white lights and a siren on the roof.
  Underglow        Coloured lights under the vehicle. The driver turns
                   them on or off and changes the colour (or rainbow).
                   Runs on the vehicle's power while the engine runs;
                   with the engine off it needs a 9V battery.

  OTHER ITEMS (carried, not fitted)
  Car Key          A key with a remote fob that locks and unlocks its
                   paired car. Off until the server turns on "Car keys
                   lock and unlock cars". Copies need a working key.
  Car Tracker      Handheld receiver: pair it with a car that has a
  Receiver         tracker fitted to find it on a map. Needs a 9V battery.
  Spike Strip      Lay it across a road: any tyre that rolls over it is
                   ruined. Wears out after 12 tyres (server setting) and
                   does nothing inside a no-damage zone.
  Jump Cables      Start a car with a flat battery from another vehicle
                   with its engine running within 8 m. Wear out after 20
                   starts (server setting).
  Radar Speed Gun  Reads the speed of a moving vehicle within 600 m.
                   Needs a 9V battery.
  Car Glass        Repairs a cracked, shattered or broken window (body,
  Repair Kit       door, hood or trunk) back to worn. 4 uses, one window
                   each.

  The ECU Tune Kit, Sports Exhaust and Underglow also fit the
  vanilla cars and the vanilla Motorbike_02. They never fit boats
  or aircraft.

  The underglow used to be a separate mod (Callatic_Vehicles_Underglow).
  It is now part of this mod: remove the old underglow mod from your
  server and launch parameters.

----------------------------------------------------------------
  DEFAULT KEYS  (Options > Controls > CZ Autoz)
----------------------------------------------------------------
  Shift + F10    Vehicle Admin Panel (admins only). With the CZ Autoz
                 helicopter mod loaded, F10 opens the helicopter panel;
                 each panel also has a tab that opens the other.
  O              My vehicle settings (HUD, units, chime)
  N              Satnav map on or off
  Ctrl + N       Set a satnav destination
  Numpad + / -   Satnav zoom
  B              Seatbelt
  K              Cruise control
  T (hold)       Nitrous
  I              Lightbar lights
  P              Siren

----------------------------------------------------------------
  LOOKS, WASHING AND REPAIRS
----------------------------------------------------------------
  Vehicles get dirty off-road (dust, mud, grass or sand) and show damage
  on the body. Rain, and driving through rivers, ponds and the sea,
  slowly wash them. Players can also wash a vehicle with a rag and
  water (crouch next to it), and weld bodywork, doors, the hood and
  trunk back into shape with a blowtorch.
  Admins can set a vehicle's dirt (kind and level) and damage look
  straight from the Vehicle Admin Panel (FLEET tab, under the
  vehicle buttons), for setting up screenshots or testing. It uses
  the fleet.repair permission and every change is logged.

----------------------------------------------------------------
  WATER
----------------------------------------------------------------
  In deep water vehicles float, drift and rock on the surface, then
  slowly fill with water and sink (45 seconds by default). Turn it
  off, or change the time, in the Vehicle Admin Panel. It also works
  on vanilla cars and motorbikes and on other mods' cars (never on
  aircraft); there is a switch for that in the panel too.
  Driving through shallow water, such as fords, streams and the
  edges of lakes, throws spray up behind the wheels, more the faster
  you go.

----------------------------------------------------------------
  SERVER FILES  (written by the server, only for what you run)
----------------------------------------------------------------
  profiles\CZAutoz\Cars\AllCars.json        settings for every vehicle
  profiles\CZAutoz\Cars\Packs\<pack>.json    settings for one tier or pack
  profiles\CZAutoz\Cars\Vehicles\<car>.json  settings for one vehicle
  profiles\CZAutoz\Cars\permissions_admins_config.json
                                             admins and roles (who can open
                                             the admin panel, what they may do)
  profiles\CZAutoz\Cars\Zones.json           speed-limit and no-damage zones
  profiles\CZAutoz\Cars\Logs\                admin actions, vehicle history
                                             and dashcam events

  Change everything from the Vehicle Admin Panel in game. A single
  vehicle's settings carry over if you later switch to its tier or
  pack (and back).

----------------------------------------------------------------
  HELP & DOCS
----------------------------------------------------------------
  Docs:     https://docs.czautoz.co.uk
  Discord:  https://discord.gg/kAm8KyH58d

  A vouch in #cz-vouches really helps, you can also go https://czautoz.co.uk to vouch. Thank you!
================================================================
