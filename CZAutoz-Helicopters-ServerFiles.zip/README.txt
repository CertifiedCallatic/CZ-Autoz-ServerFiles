================================================================
  CZ AUTOZ  -  by Callatic
  Server setup files :: Helicopter Core System
================================================================

  ***  HOW TO INSTALL  -  PLEASE READ  ***

----------------------------------------------------------------
  WHAT IS IN THIS BUNDLE
----------------------------------------------------------------
  8 aircraft / 34 airframe variants, plus their livery-specific
  doors and wheels and the shared equipment items.

    UH-1H Iroquois        4 variants
    MH-6 Little Bird      2 variants
    MD500 Civilian        4 variants
    SA342M Gazelle        3 variants
    MH-60L Black Hawk     6 variants
    AW101 Merlin          4 variants
    MH-47G Chinook        6 variants   (rear ramp, 27 seats, sling loading)
    Barrel Helicopter     5 variants   (player-built - see below)



  Almost every file in this folder is MERGED into a file you
  ALREADY have on your server. OPEN your existing file and PASTE
  the new entries in. Do NOT drop these in to overwrite / replace
  your server files - that would wipe your own setup.

  The ONE exception is Trader_ExpansionMarket.json, which is a
  brand-new category file you ADD to your Market folder (it does
  not replace anything).

----------------------------------------------------------------
  ECONOMY FILES
----------------------------------------------------------------
  types.xml                    MERGE the <type> entries into your EXISTING
                               mpmissions\<your.map>\db\types.xml
  events.xml                   MERGE the <event> entries into your EXISTING
                               mpmissions\<your.map>\db\events.xml
  cfgeventspawns.xml           MERGE the <event> position blocks into your
                               EXISTING mpmissions\<your.map>\cfgeventspawns.xml

----------------------------------------------------------------
  TRADER FILES  (use the one for your trader mod)
----------------------------------------------------------------
  Trader_DrJones.txt           MERGE the <Category> blocks into your EXISTING
                               TraderConfig.txt  (Trader by Dr Jones)
  Trader_TraderPlus.json       MERGE the categories into the "TraderCategories"
                               array of your EXISTING TraderPlusPriceConfig.json
  Trader_ExpansionMarket.json  ADD this as a NEW category file in your profile's
                               ExpansionMod\Market\ folder (sits alongside your
                               other market files, replaces nothing) - OR merge its
                               "Items" into one of your existing category files.

  Prices are pre-set and identical across all three systems.
  Helicopters sell as vehicles (with key); doors and wheels sell as
  items, and so do the Battery, Repair Kit and Fuel Drum. Expansion
  vehicles include SpawnAttachments so they sell built.

----------------------------------------------------------------
  QUICK SETUP
----------------------------------------------------------------
  1. WHITELIST your server IP + port in #ip-whitelisting on our
     Discord. Until you do, helicopters spawn but the engines
     WON'T start (flight is disabled until your server is registered).
  2. OPEN your mission's db\types.xml and MERGE in the entries from
     types.xml here (keep all of your existing entries).
  3. Add the helicopters to ONE trader by MERGING the matching trader
     file into your existing trader config (see above).
  4. (Optional) MERGE events.xml + cfgeventspawns.xml into your
     existing files for fixed map spawns.
  No cfgeconomycore.xml edit needed (CarScript-based, native CE root),
  and NO Community Framework required (native whitelisting since v0.2.3).

  Parts: helicopter doors / wheels are livery-specific and are set to
  nominal=0 (no loot spam). The Battery, Repair Kit and Fuel Drum spawn
  in loot. Helicopters never auto-spawn.

  BARREL HELICOPTER: this one is BUILT, not spawned. A player cuts open
  a barrel, then bolts on ten parts and four wheels using the Helicopter
  Repair Kit. Those thirteen part classnames are the ONLY ones in this bundle
  set to spawn in loot as Industrial - they are the route to the aircraft,
  so set nominal=0 on them only if your traders sell them instead. The
  colour of the barrel decides the colour of the finished helicopter
  (red, blue, green or yellow). The part-built frame is a world object
  with the same lifetime as a helicopter, so an unfinished build survives
  a logout and a restart.

  REQUIRED ITEM: a CZ_HelicopterBattery must be fitted to start a
  helicopter. The Repair Kit repairs it; the Fuel Drum refuels it.

  FUEL DRUM CLASSNAME: use CZ_HeliDrum. CZAutoz_HeliDrum is the old
  name and is kept in these files only so existing servers keep
  working - both are listed, you only need CZ_HeliDrum on a new setup.

----------------------------------------------------------------
  HELP & DOCS
----------------------------------------------------------------
  Docs:     https://docs.czautoz.co.uk
  Discord:  https://discord.gg/kAm8KyH58d

  A vouch in #cz-vouches and a Workshop upvote really help. Thank you!
================================================================
