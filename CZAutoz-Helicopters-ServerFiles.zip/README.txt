================================================================
  CZ AUTOZ  -  by Callatic
  Server setup files :: Helicopter Core System
================================================================

  ***  HOW TO INSTALL  -  PLEASE READ  ***

----------------------------------------------------------------
  WHAT IS IN THIS BUNDLE
----------------------------------------------------------------
  12 aircraft / 49 airframe variants, plus their livery-specific
  doors and wheels and the shared equipment items.

    UH-1H Iroquois        4 variants
    MH-6 Little Bird      7 variants
    MD500 Civilian        4 variants
    SA342M Gazelle        3 variants
    MH-60L Black Hawk     6 variants
    AW101 Merlin          4 variants
    MH-47G Chinook        6 variants   (rear ramp, 27 seats, sling loading)
    CH-47D Chinook        4 variants   (rear ramp, 24 seats, sling loading)
    Mi-24 Hind            5 variants   (4 seats, walk-in troop cabin)
    CV-22B Osprey         1 variant    (tilt-rotor, rear ramp, 22 seats, sling loading)
    MV-22B Osprey         1 variant    (tilt-rotor, rear ramp, 22 seats, sling loading)
    Barrel Helicopter     4 variants   (player-built - see below)



  Almost every file in this folder is MERGED into a file you
  ALREADY have on your server. OPEN your existing file and PASTE
  the new entries in. Do NOT drop these in to overwrite / replace
  your server files - that would wipe your own setup.

  The ONE exception is Trader_ExpansionMarket.json, which is a
  brand-new category file you ADD to your Market folder (it does
  not replace anything).

----------------------------------------------------------------
  ECONOMY FILES
----------------------------------------------------------------
  types.xml                    MERGE the <type> entries into your EXISTING
                               mpmissions\<your.map>\db\types.xml
  events.xml                   MERGE the <event> entries into your EXISTING
                               mpmissions\<your.map>\db\events.xml
  cfgeventspawns.xml           MERGE the <event> position blocks into your
                               EXISTING mpmissions\<your.map>\cfgeventspawns.xml

----------------------------------------------------------------
  TRADER FILES  (use the one for your trader mod)
----------------------------------------------------------------
  Trader_DrJones.txt           MERGE the <Category> blocks into your EXISTING
                               TraderConfig.txt  (Trader by Dr Jones)
  Trader_TraderPlus.json       (PRICES) MERGE the categories into the
                               "TraderCategories" array of your EXISTING
                               TraderPlusPriceConfig.json
  Trader_TraderPlus_VehiclesConfig.json  (ATTACHMENTS) MERGE the entries
                               into the "VehiclesParts" array of your EXISTING
                               TraderPlusVehiclesConfig.json, so a bought
                               helicopter arrives with its doors, wheels, battery
                               and headlight instead of bare
  Trader_ExpansionMarket.json  ADD this as a NEW category file in your profile's
                               ExpansionMod\Market\ folder (replaces nothing), THEN
                               list it on a trader - add the category to that trader's
                               Categories in ExpansionMod\Traders\, or it exists but
                               nothing shows for sale. OR skip that by merging its
                               "Items" into a category a trader already sells.

  Prices are pre-set and identical across all three systems.
  Helicopters sell as vehicles (with key); doors and wheels sell as
  items, and so do the Battery, Repair Kit, Flip Wrench and Fuel Drum.
  Expansion vehicles include SpawnAttachments so they sell built.

----------------------------------------------------------------
  QUICK SETUP
----------------------------------------------------------------
  1. WHITELIST your server IP + port in #ip-whitelisting on our
     Discord. Until you do, helicopters spawn but the engines
     WON'T start (flight is disabled until your server is registered).
  2. OPEN your mission's db\types.xml and MERGE in the entries from
     types.xml here (keep all of your existing entries).
  3. Add the helicopters to ONE trader by MERGING the matching trader
     file into your existing trader config (see above).
  4. (Optional) MERGE events.xml + cfgeventspawns.xml into your
     existing files for fixed map spawns.
  No cfgeconomycore.xml edit needed (CarScript-based, native CE root),
  and NO Community Framework required (native whitelisting since v0.2.3).

  Parts: helicopter doors / wheels are livery-specific and are set to
  nominal=0 (no loot spam). The Battery, Repair Kit, Flip Wrench and Fuel
  Drum spawn in loot. Helicopters never auto-spawn.

  BARREL HELICOPTER: this one is BUILT, not spawned. A player opens a
  barrel with the Barrel Cutting Torch, bolts ten parts into the frame
  and builds each one in turn with the Airframe Assembly Wrench (a part
  that is only bolted in stays invisible until it is built), fits four
  wheels once the undercarriage is built, and the wrench signs the
  finished aircraft off. The thirteen part classnames and the two tools
  are the ONLY entries in this bundle set to spawn in loot as Industrial
  - they are the route to the aircraft, so set nominal=0 on them only if
  your traders sell them instead. The colour of the barrel decides the
  colour of the finished helicopter: CZ_BarrelHeli is the red one, the
  blue, green and yellow ones have their own classnames. The part-built
  frame is a world object with the same lifetime as a helicopter, so an
  unfinished build survives a logout and a restart, and it takes the
  battery and the landing-light bulb so the finished aircraft has both.

  REQUIRED ITEM: a CZ_HelicopterBattery must be fitted to start a
  helicopter. The Repair Kit repairs it; the Fuel Drum refuels it.

  FLIP WRENCH: CZ_HelicopterFlipWrench stands a helicopter back on its
  gear after a crash leaves it lying on its side - hold the action
  beside the aircraft. Four uses per wrench. It works whatever the
  groundFlipRecovery setting says, so leave it out of your loot and
  traders if you want crashes on your server to be final.

  FUEL DRUM CLASSNAME: use CZ_HeliDrum. CZAutoz_HeliDrum is the old
  name and is kept in these files only so existing servers keep
  working - both are listed, you only need CZ_HeliDrum on a new setup.

----------------------------------------------------------------
  HELP & DOCS
----------------------------------------------------------------
  Docs:     https://docs.czautoz.co.uk
  Discord:  https://discord.gg/kAm8KyH58d

  A vouch in #cz-vouches and a Workshop upvote really help. Thank you!
================================================================
