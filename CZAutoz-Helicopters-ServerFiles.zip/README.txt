================================================================
  CZ AUTOZ  -  by Callatic
  Server setup files :: Helicopter Core System
================================================================

  ***  HOW TO INSTALL  -  PLEASE READ  ***

  Almost every file in this folder is MERGED into a file you
  ALREADY have on your server. OPEN your existing file and PASTE
  the new entries in. Do NOT drop these in to overwrite / replace
  your server files - that would wipe your own setup.

  The ONE exception is Trader_ExpansionMarket.json, which is a
  brand-new category file you ADD to your Market folder (it does
  not replace anything).

----------------------------------------------------------------
  ECONOMY FILES
----------------------------------------------------------------
  types.xml                    MERGE the <type> entries into your EXISTING
                               mpmissions\<your.map>\db\types.xml
  events.xml                   MERGE the <event> entries into your EXISTING
                               mpmissions\<your.map>\db\events.xml
  cfgeventspawns.xml           MERGE the <event> position blocks into your
                               EXISTING mpmissions\<your.map>\cfgeventspawns.xml

----------------------------------------------------------------
  TRADER FILES  (use the one for your trader mod)
----------------------------------------------------------------
  Trader_DrJones.txt           MERGE the <Category> blocks into your EXISTING
                               TraderConfig.txt  (Trader by Dr Jones)
  Trader_TraderPlus.json       MERGE the categories into the "TraderCategories"
                               array of your EXISTING TraderPlusPriceConfig.json
  Trader_ExpansionMarket.json  ADD this as a NEW category file in your profile's
                               ExpansionMod\Market\ folder (sits alongside your
                               other market files, replaces nothing) - OR merge its
                               "Items" into one of your existing category files.

  Prices are pre-set and identical across all three systems.
  Helicopters sell as vehicles (with key); doors and wheels sell as
  items, and so do the Battery, Repair Kit and Fuel Drum. Expansion
  vehicles include SpawnAttachments so they sell built.

----------------------------------------------------------------
  QUICK SETUP
----------------------------------------------------------------
  1. WHITELIST your server IP + port in #ip-whitelisting on our
     Discord. Until you do, helicopters spawn but the engines
     WON'T start (flight is disabled until your server is registered).
  2. OPEN your mission's db\types.xml and MERGE in the entries from
     types.xml here (keep all of your existing entries).
  3. Add the helicopters to ONE trader by MERGING the matching trader
     file into your existing trader config (see above).
  4. (Optional) MERGE events.xml + cfgeventspawns.xml into your
     existing files for fixed map spawns.
  No cfgeconomycore.xml edit needed (CarScript-based, native CE root),
  and NO Community Framework required (native whitelisting since v0.2.3).

  Parts: helicopter doors / wheels are livery-specific and are set to
  nominal=0 (no loot spam). The Battery, Repair Kit and Fuel Drum spawn
  in loot. Helicopters never auto-spawn.

  REQUIRED ITEM: a CZ_HelicopterBattery must be fitted to start a
  helicopter. The Repair Kit repairs it; the Fuel Drum refuels it.

----------------------------------------------------------------
  HELP & DOCS
----------------------------------------------------------------
  Docs:     https://docs.czautoz.co.uk
  Discord:  https://discord.gg/7qWZzPUuTq

  A vouch in #cz-vouches and a Workshop upvote really help. Thank you!
================================================================
